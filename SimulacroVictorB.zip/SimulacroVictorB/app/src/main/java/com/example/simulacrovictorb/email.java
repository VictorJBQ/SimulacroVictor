package com.example.simulacrovictorb;

public class email {
    private String remitente;
    private String asunto;
    private String mensaje;

    public email(String remitente, String asunto, String mensaje) {
        this.remitente = remitente;
        this.asunto = asunto;
        this.mensaje = mensaje;
    }

    public String getRemitente() {
        return remitente;
    }

    public void setRemitente(String remitente) {
        this.remitente = remitente;
    }

    public String getAsunto() {
        return asunto;
    }

    public void setAsunto(String asunto) {
        this.asunto = asunto;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
}
