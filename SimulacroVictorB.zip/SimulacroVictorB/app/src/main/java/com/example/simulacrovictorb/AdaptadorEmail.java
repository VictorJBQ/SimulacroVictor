package com.example.simulacrovictorb;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

public class AdaptadorEmail extends ArrayAdapter<email> {
    Context ctx;
    ArrayList<email> listaEmail;
    int layoutTemplate;
    public AdaptadorEmail(@NonNull Context context, int resource, @NonNull List<email> objects) {
        super(context, resource, objects);
        ctx=context;
        layoutTemplate=resource;
        listaEmail=(ArrayList<email>) objects;
    }
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view= LayoutInflater.from(ctx).inflate(layoutTemplate,parent,false);
        TextView autor = view.findViewById(R.id.textViewAutor);
        TextView asunto =  view.findViewById(R.id.textViewAsunto);
        TextView mensaje= view.findViewById(R.id.textViewMensaje);
        autor.setText(" "+listaEmail.get(position).getRemitente());
        asunto.setText(" "+listaEmail.get(position).getAsunto());
        mensaje.setText(" "+listaEmail.get(position).getMensaje());
        return view;
    }
}
