package com.example.simulacrovictorb;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ListView listViewCorreo;
    private ArrayList<email> email;
    private AdaptadorEmail adaptadorEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listViewCorreo=(ListView) findViewById(R.id.listViewBandeja);

        email= new ArrayList<email>();
        email.add(new email("David","Informacion Importante","El proximo domingo nos reuniremos para debatir los presuspuesto de la Comunidad de vecinos"));
        email.add(new email("Rosa Chacel","Informacion del dia","Bajar a firmar los horarios"));
        email.add(new email("Facebook","Nuevos Mensajes","Tienes nuevos mensajes de fulanito y manganito"));

        adaptadorEmail= new AdaptadorEmail(this,R.layout.email_item,email);
        listViewCorreo.setAdapter(adaptadorEmail);

        listViewCorreo.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                TextView autor1 = view.findViewById(R.id.textViewAutor);
                autor1.setTypeface(null,Typeface.NORMAL);
                FragmentManager fragmentManager =  getSupportFragmentManager();
                emailFragment emailfragment1 = emailFragment.newInstance(email.get(i).getRemitente(),email.get(i).getAsunto(),email.get(i).getMensaje());
                fragmentManager.beginTransaction().add(R.id.contenedorPrincipal,emailfragment1,null).commit();
            }
        });
    }

}